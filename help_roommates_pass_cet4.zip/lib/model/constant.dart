class Constant {
  Constant._();
  static const uesrName = 'user_name';
  static const passwordKey = 'password_key';
  static const dbName = 'cet4.db';
  static const L_num = '0';
  static const dbVersion = 1;
}