package com.hjnodm.helproommatespasscet4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
